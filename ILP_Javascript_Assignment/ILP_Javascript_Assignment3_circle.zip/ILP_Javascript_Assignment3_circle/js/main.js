const plusButton = document.getElementById('plusButton');
const minusButton = document.getElementById('minusButton');

let clickCounter_add = 0;

function countClicks_add(button) {
    clickCounter_add++;
    console.log(button)
    fillCircles(clickCounter_add);
}


function fillCircles(rowNumber) {
    const row = document.getElementById(`row${rowNumber}`);
    const circles = row.querySelectorAll('.circle');
    circles.forEach(circle => {
        circle.style.backgroundColor = 'red';
    });
}

function countClicks_minus(button) {
    clickCounter_minus--;
    clearCircles(++clickCounter_minus);
}

function clearCircles(rowNumber) {
    const row = document.getElementById(`row${rowNumber}`);
    const circles = row.querySelectorAll('.circle');
    circles.forEach(circle => {
        circle.style.backgroundColor = '';
    });
}



// function fillColor() {
//     const circles = document.querySelectorAll('.circle');
//     circles.forEach(circle => {
//         circle.classList.add('active');
//     });
// }

// function clearColor() {
//     const circles = document.querySelectorAll('.circle');
//     circles.forEach(circle => {
//         circle.classList.remove('active');
//     });
// }